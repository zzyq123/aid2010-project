from flask import Flask, send_file
import sys


app = Flask(__name__)

@app.route("/rank")
def rank():
    return send_file("templates/rank.html")

@app.route("/book/<bookname>")
def book(bookname):
    return send_file("templates/book.html")

if __name__ == '__main__':
    app.run(port=5555,debug=True)