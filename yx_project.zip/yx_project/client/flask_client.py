from flask import Flask, send_file
import sys


app = Flask(__name__)
@app.route("/book/<bookname>")
def book(bookname):
    return send_file("templates/book.html")

@app.route("/register")
def register():
    return send_file("templates/register.html")

@app.route("/login")
def login():
    return send_file("templates/login.html")

@app.route("/comment/<bookname>")
def comment(bookname):
    return send_file("templates/comment.html")

@app.route("/uploadbook")
def uploadbook():
    return send_file("templates/uploadbook.html")

@app.route("/niubi")
def niubi():
    return send_file("templates/niubi.html")

@app.route("/niubi/allrank")
def niubi_allrank():
    return send_file("templates/niubi_allrank.html")

@app.route("/niubi/allrank/all/<rank>")
def niubi_allrank_all_rank(rank):
    return send_file("templates/niubi_allrank_all_rank.html")

@app.route("/niubi/allrank/<category>")
def niubi_allrank_category(category):
    return send_file("templates/niubi_allrank_category.html")


@app.route("/niubi/allrank/<category>/<rank>")
def niubi_allrank_category_rank(category,rank):
    return send_file("templates/niubi_allrank_category_rank.html")

@app.route("/niubi/allbook")
def niubi_allbook():
    return send_file("templates/niubi_allbook.html")

@app.route("/niubi/allbook/all/<rank>")
def niubi_allbook_all_rank(rank):
    return send_file("templates/niubi_allbook_all_rank.html")

@app.route("/niubi/allbook/<category>/<rank>")
def niubi_allbook_category_rank(category,rank):
    return send_file("templates/niubi_allbook_category_rank.html")

@app.route("/user_center")
def user_center():
    return send_file("templates/user_center.html")

@app.route("/user_center/balance")
def user_center_balance():
    return send_file("templates/user_center_balance.html")

@app.route("/user_center/ticket")
def user_center_ticket():
    return send_file("templates/user_center_ticket.html")

@app.route("/user_center/setting")
def user_center_setting():
    return send_file("templates/user_center_setting.html")

@app.route("/user_center/security/home")
def user_center_security_home():
    return send_file("templates/user_center_security_home.html")

@app.route("/user_center/security/bindphone")
def user_center_security_bindphone():
    return send_file("templates/user_center_security_bindphone.html")

@app.route("/user_center/security/bindphone/phone/verify")
def user_center_security_bindphone_phone_verify():
    return send_file("templates/user_center_security_bindphone_phone_verify.html")

@app.route("/user_center/security/bindphone/phone/set")
def user_center_security_bindphone_phone_set():
    return send_file("templates/user_center_security_bindphone_phone_set.html")

@app.route("/user_center/security/bindphone/phone/result")
def user_center_security_bindphone_phone_result():
    return send_file("templates/user_center_security_bindphone_phone_result.html")

@app.route("/user_center/security/bindphone/mail/verify")
def user_center_security_bindphone_mail_verify():
    return send_file("templates/user_center_security_bindphone_mail_verify.html")

@app.route("/user_center/security/bindphone/mail/set")
def user_center_security_bindphone_mail_set():
    return send_file("templates/user_center_security_bindphone_mail_set.html")

@app.route("/user_center/security/bindphone/mail/result")
def user_center_security_bindphone_mail_result():
    return send_file("templates/user_center_security_bindphone_mail_result.html")

@app.route("/user_center/security/bindmail")
def user_center_security_bindmail():
    return send_file("templates/user_center_security_bindmail.html")

@app.route("/user_center/security/bindmail/phone/verify")
def user_center_security_bindmail_phone_verify():
    return send_file("templates/user_center_security_bindmail_phone_verify.html")

@app.route("/user_center/security/bindmail/phone/set")
def user_center_security_bindmail_phone_set():
    return send_file("templates/user_center_security_bindmail_phone_set.html")

@app.route("/user_center/security/bindmail/phone/result")
def user_center_security_bindmail_phone_result():
    return send_file("templates/user_center_security_bindmail_phone_result.html")

@app.route("/user_center/security/bindmail/mail/verify")
def user_center_security_bindmail_mail_verify():
    return send_file("templates/user_center_security_bindmail_mail_verify.html")

@app.route("/user_center/security/bindmail/mail/set")
def user_center_security_bindmail_mail_set():
    return send_file("templates/user_center_security_bindmail_mail_set.html")

@app.route("/user_center/security/bindmail/mail/result")
def user_center_security_bindmail_mail_result():
    return send_file("templates/user_center_security_bindmail_mail_result.html")

@app.route("/user_center/security/setpassword")
def user_center_security_setpassword():
    return send_file("templates/user_center_security_setpassword.html")

@app.route("/user_center/security/setpassword/phone/verify")
def user_center_security_setpassword_phone_verify():
    return send_file("templates/user_center_security_setpassword_phone_verify.html")

@app.route("/user_center/security/setpassword/phone/set")
def user_center_security_setpassword_phone_set():
    return send_file("templates/user_center_security_setpassword_phone_set.html")

@app.route("/user_center/security/setpassword/phone/result")
def user_center_security_setpassword_phone_result():
    return send_file("templates/user_center_security_setpassword_phone_result.html")

@app.route("/user_center/security/setpassword/mail/verify")
def user_center_security_setpassword_mail_verify():
    return send_file("templates/user_center_security_setpassword_mail_verify.html")

@app.route("/user_center/security/setpassword/mail/set")
def user_center_security_setpassword_mail_set():
    return send_file("templates/user_center_security_setpassword_mail_set.html")

@app.route("/user_center/security/setpassword/mail/result")
def user_center_security_setpassword_mail_result():
    return send_file("templates/user_center_security_setpassword_mail_result.html")

if __name__ == '__main__':
    app.run(port=5555,debug=True)