import jwt
from django.conf import settings
from django.http import JsonResponse
from django.shortcuts import render

# Create your views here.
from django.utils.decorators import method_decorator
from django.views import View

from tools.nickname_check import nickname_check
from user.models import UserProfile


class HomePageView(View):
    @method_decorator(nickname_check)
    # 为前端返回主页内容
    def get(self,request):
        nickname = request.mynickname
        result = {"code":200,"nickname":nickname}
        return JsonResponse(result)

