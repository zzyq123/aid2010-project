from django.apps import AppConfig


class UserRecordRewardConfig(AppConfig):
    name = 'user_record_expense'
