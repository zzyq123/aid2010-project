import redis
from django.http import JsonResponse
from django.shortcuts import render

# Create your views here.
from django.utils.decorators import method_decorator
from django.views import View

from tools.login_check import login_check
from user_record_expense.models import ExpenseRecord


class UserRecordReward(View):
    # 显示用户打赏和订阅记录
    @method_decorator(login_check)
    def get(self,request):
        user = request.myuser
        r = redis.Redis()
        balance = r.hget(user.username + "_data", "balance").decode()
        expense_records = ExpenseRecord.objects.filter(user_profile=user).order_by('-created_time')
        expense_record_list = [{"title": expense_record.title,
                               "created_time": expense_record.created_time.strftime('%Y-%m-%d %H:%M:%S'),
                               "reward_count": expense_record.reward_count,
                               "subscription_count":expense_record.subscription_count
                               } for expense_record in expense_records]
        (total_reward, total_subscription, total_balance) = calculate_count(user)
        print(total_subscription)
        print(total_reward)
        print(expense_record_list)
        result = {"code": 200, "data": {
            "nickname": user.nickname,
            "balance": balance,
            "expense_record_list": expense_record_list,
            "total_reward": total_reward,
            "total_subscription": total_subscription,
            "total_balance": total_balance
        }}
        return JsonResponse(result)

# 计算用户使用月票和消费总数
def calculate_count(user):
    reward_count_list = ExpenseRecord.objects.values_list("reward_count").filter(user_profile=user)
    reward_counts_tuple = [reward_count_tuple[0] for reward_count_tuple in reward_count_list]
    total_reward = sum(reward_counts_tuple)
    subscription_count_list = ExpenseRecord.objects.values_list("subscription_count").filter(user_profile=user)
    subscription_counts_tuple = [subscription_count_tuple[0] for subscription_count_tuple in subscription_count_list]
    total_subscription = sum(subscription_counts_tuple)
    total_balance = total_reward + total_subscription
    return total_reward,total_subscription,total_balance