list01 = []
tuple01= (("1",1),("2",2),("3",3))
for i in range (len(tuple01)):

    tuple01[i][0].encode()
print(tuple01)
print(list01)

list02 = ["1","3","45"]
for i in range(len(list02)):
    list02[i].encode()
print(list02)

a = "2"
a.encode()
list01.append(a.encode())
print(list01)