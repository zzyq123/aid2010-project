"""fiction URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from user import views as user_views
from rank import views as rank_views
from login import views as login_views
from book import views as book_views
from home_page import views as home_page_views
from user_security_phone import views as user_security_phone_views
from user_security_password import views as user_security_password_views
from user_security_mail import views as user_security_mail_views
from user_action import views as user_action_views
from user_record_ticket import views as user_record_ticket_views
from user_record_expense import views as user_record_expense_views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('v1/rank/',include("rank.urls")),
    path('v1/book/',include("book.urls")),
    path('v1/login',login_views.LoginView.as_view()),
    path('v1/uploadbook',book_views.uploadbook),
    path('v1/comment/',include("comment.urls")),
    path('v1/home_page',home_page_views.HomePageView.as_view()),
    path('v1/user/',include("user.urls")),
    path('v1/user',user_views.UserView.as_view()),
    path('v1/user_security_phone',user_security_phone_views.UserSecurityPhoneView.as_view()),
    path('v1/user_security_password',user_security_password_views.UserSecurityPasswordView.as_view()),
    path('v1/user_security_mail',user_security_mail_views.UserSecurityMailView.as_view()),
    path('v1/user_security_mail/',include("user_security_mail.urls")),
    path('v1/user_action/',include('user_action.urls')),
    path('v1/user_action',user_action_views.UserActionView.as_view()),
    path('v1/user_record_ticket',user_record_ticket_views.UserRecordTicket.as_view()),
    path('v1/user_record_expense',user_record_expense_views.UserRecordReward.as_view()),
]
