import jwt
from django.conf import settings
from django.http import JsonResponse

from user.models import UserProfile

#判断用户是否登录，此装饰器用在必须登录用户才能操作的功能上，未登录用户会被弹出到登录界面
def login_check(fuc):
    def wrap(request,*args,**kwargs):
        token = request.META.get("HTTP_AUTHORIZATION")
        if not token:
            result = {"code":10401,"error":"请登录!"}
            return JsonResponse(result)
        try:
            payload =jwt.decode(token,settings.JWT_TOKEN_KEY,algorithms="HS256")
        except:
            result = {"code":10402,"error":"请登录"}
            return JsonResponse(result)
        username = payload["username"]
        try:
            user = UserProfile.objects.get(username=username)
        except:
            user = UserProfile.objects.get(phone=username)
        request.myuser = user
        res = fuc(request,*args,**kwargs)
        return res
    return wrap

