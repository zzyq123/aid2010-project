from django.core.cache import cache
from django.http import JsonResponse

# 此装饰器用在用户更改安全设置，验证身份时
def verify(func):
    def wrap(request,*args,**kwargs):
        user = request.myuser
        user_phone = user.phone
        user_email = user.email
        cache_key = "sms_%s" % user_phone
        code_phone = cache.get(cache_key)
        cache_key = "sms_email%s" % user_email
        code_email = cache.get(cache_key)
        if not code_phone and not code_email:
            result = {"code": 10603, "error": "身份验证过期"}
            return JsonResponse(result)
        res = func(request,*args,**kwargs)
        return res
    return wrap