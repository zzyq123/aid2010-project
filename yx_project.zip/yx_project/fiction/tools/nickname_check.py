import jwt
from django.conf import settings
from django.http import JsonResponse

from user.models import UserProfile

# 判断用户是否登录，此装饰器用在无需登录也能操作的功能上，
# 并判断用户在浏览不需要登录的页面时用户中心（网页右上角）显示登录按钮还是用户昵称
def nickname_check(fuc):
    def wrap(request,*args,**kwargs):
        token = request.META.get("HTTP_AUTHORIZATION")
        if not token:
            print(1)
            nickname = ""
            request.mynickname = nickname
            res = fuc(request, *args, **kwargs)
            return res
        try:
            payload = jwt.decode(token, settings.JWT_TOKEN_KEY, algorithms="HS256")
        except:
            nickname = ""
            request.mynickname = nickname
            res = fuc(request, *args, **kwargs)
            return res
        username = payload["username"]
        try:
            user = UserProfile.objects.get(username=username)
        except:
            user = UserProfile.objects.get(phone=username)
        nickname = user.nickname
        request.mynickname = nickname
        res = fuc(request,*args,**kwargs)
        return res
    return wrap