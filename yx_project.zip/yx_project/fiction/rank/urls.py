from django.urls import path
from . import views

urlpatterns = [
    path('all_rank',views.all_rank),
    path('all_rank/all/<str:category>',views.all_rank_category),
    path('<str:ranktype>',views.RankView.as_view()),
    path('<str:category>/<str:ranktype>',views.category_rank),

]