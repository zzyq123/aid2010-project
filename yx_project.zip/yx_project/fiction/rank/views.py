from django.core.cache import cache
from django.http import JsonResponse
from django.shortcuts import render
import redis
# Create your views here.
from django.views import View


class RankView(View):
    def get(self,request):
        r = redis.Redis()
        #需要提前创建好redis中的内容，下面代码为创建redis有序集合代码，不可在此函数使用，
        #否则每次运行都会清空redis库！

        # r.zadd("zk1", {"yx": 0,"yx3":0, "yx2": 0,"yx4":0,"yx5":0,
        #                "yx6":0})

        #redis有序集合倒序排列
        zrevrange_zk1=r.zrevrange("zk1",0,-1,withscores=True)
        zk1_list = []
        for i in range(len(zrevrange_zk1)):
            #将元素中的键从字节串变为字符串
            zk1_list.append((zrevrange_zk1[i][0].decode(),zrevrange_zk1[i][1]))
        print(zk1_list)
        result = {"code":200,"data":zk1_list}
        return JsonResponse(result)

    def post(self,request):
        result = {"code":200}
        return JsonResponse(result)
