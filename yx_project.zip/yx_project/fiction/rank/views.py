from django.core.cache import cache
from django.http import JsonResponse
from django.shortcuts import render
import redis
# Create your views here.
from django.utils.decorators import method_decorator
from django.views import View

from tools.nickname_check import nickname_check


class RankView(View):
    # 为前段提取总分类的对应排行榜
    @method_decorator(nickname_check)
    def get(self,request,ranktype):
        r = redis.Redis()
        zrevrange_zk1 = r.zrevrange("total_" + ranktype, 0, -1, withscores=True)
        res = transform_zk1(request, zrevrange_zk1)
        return res

    # 这个不知道是干啥的，写忘记了，但是不要删除，避免出现奇怪的错误
    def post(self,request):
        result = {"code":200}
        return JsonResponse(result)

# 为前段提取各种作品分类的对应排行榜
@nickname_check
def category_rank(request,category,ranktype):
    r = redis.Redis()
    zrevrange_zk1 = r.zrevrange(category+"_"+ranktype, 0, -1, withscores=True)
    res = transform_zk1(request,zrevrange_zk1)
    return res

# 为前段提取总分类的所有排行榜
@nickname_check
def all_rank(request):
    res = transform_all_rank(request,make_all_rank)
    return res

# 为前段提取各种作品分类的所有排行榜
@nickname_check
def all_rank_category(request,category):
    res = transform_all_rank(request,make_all_rank_category,category)
    return res

# 为了能进行json串传输，将redis库中字段从字节串变为字符串
def transform_zk1(request,zrevrange_zk1):
    zk1_list = []
    for i in range(len(zrevrange_zk1)):
        # 将字段从字节串变为字符串
        zk1_list.append((zrevrange_zk1[i][0].decode(), zrevrange_zk1[i][1]))
    print(zk1_list)
    nickname = request.mynickname
    result = {"code": 200, "nickname": nickname, "data": zk1_list}
    return JsonResponse(result)

# 从redis中提取所有作品的所有排行榜
def make_all_rank():
    print(1)
    r = redis.Redis()
    tuple_rank = ("total_hot",
                  "total_ticket",
                  "total_reward",
                  "total_scan",
                  "total_collection",
                  "total_subscription",)
    for item in tuple_rank:
        res = r.zrevrange(item, 0, -1, withscores=True)
        yield res

# 从redis中提取对应分类作品的所有排行榜
def make_all_rank_category(category):
    r = redis.Redis()
    tuple_rank = (category + "_hot",
                  category + "_ticket",
                  category + "_reward",
                  category + "_scan",
                  category + "_collection",
                  category + "_subscription",)
    for item in tuple_rank:
        res = r.zrevrange(item, 0, -1, withscores=True)
        yield res

# 将所有redis排行榜的字段一次性全部转为字符串，并构建前段所需的json串
def transform_all_rank(request,func,*args):
    rank_tuple = ([], [], [], [], [], [])
    all_rank_dict = {}
    t = -1
    for item in func(*args):
        t += 1
        for i in range(len(item)):
            rank_tuple[t].append((item[i][0].decode(), item[i][1]))
    all_rank_dict["hot"] = rank_tuple[0]
    all_rank_dict["ticket"] = rank_tuple[1]
    all_rank_dict["reward"] = rank_tuple[2]
    all_rank_dict["scan"] = rank_tuple[3]
    all_rank_dict["collection"] = rank_tuple[4]
    all_rank_dict["subscription"] = rank_tuple[5]
    nickname = request.mynickname
    result = {"code": 200, "nickname": nickname, "data": all_rank_dict}
    return JsonResponse(result)