import redis
from django.http import JsonResponse
from django.shortcuts import render

# Create your views here.
from django.utils.decorators import method_decorator
from django.views import View

from tools.login_check import login_check
from user_record_ticket.models import TicketRecord


class UserRecordTicket(View):
    # 显示用户月票记录
    @method_decorator(login_check)
    def get(self,request):
        user = request.myuser
        r = redis.Redis()
        ticket = r.hget(user.username + "_data", "ticket").decode()
        ticket_records = TicketRecord.objects.filter(user_profile = user).order_by('-created_time')
        ticket_record_list = [{"title":ticket_record.title,
                               "created_time":ticket_record.created_time.strftime('%Y-%m-%d %H:%M:%S'),
                               "ticket_count":ticket_record.ticket_count
                               }for ticket_record in ticket_records]
        ticket_count_list = TicketRecord.objects.values_list("ticket_count").filter(user_profile = user)
        ticket_counts_tuple = [ticket_count_tuple[0]for ticket_count_tuple in ticket_count_list]
        total_ticket = sum(ticket_counts_tuple)
        print(total_ticket)
        print(ticket_count_list)
        print(ticket_record_list)
        result = {"code":200,"data":{
                                     "nickname":user.nickname,
                                     "ticket":ticket,
                                     "ticket_record_list":ticket_record_list,
                                     "total_ticket":total_ticket
                                        }}
        return JsonResponse(result)