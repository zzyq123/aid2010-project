from django.apps import AppConfig


class UserTicketRecordConfig(AppConfig):
    name = 'user_record_ticket'
