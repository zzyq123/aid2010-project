from django.db import models

# Create your models here.
from user.models import UserProfile


class TicketRecord(models.Model):
    title = models.CharField('文章标题', max_length=50)
    created_time = models.DateTimeField(auto_now_add=True)
    ticket_count = models.IntegerField(default=0)
    user_profile = models.ForeignKey(UserProfile,
                                     on_delete=models.CASCADE)
