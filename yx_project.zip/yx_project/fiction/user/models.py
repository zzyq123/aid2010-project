from django.db import models

import random


# Create your models here.
class UserProfile(models.Model):
    username = models.CharField('用户名', max_length=40,
                                primary_key=True)
    nickname = models.CharField('昵称', max_length=30)
    password = models.CharField('密码', max_length=32)
    sign = models.CharField('个人签名', max_length=50,
                            default="")
    zone_info = models.CharField('空间简介', max_length=150,
                            default='')
    email = models.EmailField('邮箱',default='')
    avatar = models.ImageField(upload_to='avatar',
                               null=True)
    phone = models.CharField('手机号', max_length=11, default='')
    created_time = models.DateTimeField(auto_now_add=True)
    updated_time = models.DateTimeField(auto_now=True)
