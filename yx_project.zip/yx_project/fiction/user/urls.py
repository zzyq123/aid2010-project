from django.urls import path
from . import views
urlpatterns = [
    path('sms',views.sms_view),
    path('check_login',views.check_login),
]