from django.conf import settings

from fiction.celery import app
from tools.sms import YunTongXin, QqEmail


@app.task
def send_sms(phone, code):
    # 一般情况下，写到配置文件中
    aid = '8a216da877373e59017741b554da051e'
    atoken = 'fc3ec442182c4897adef019483b04f31'
    appid = '8a216da877373e59017741b555c80524'
    tid = '1'

    # 1 创建云通信对象
    x = YunTongXin(aid, atoken, appid, tid)
    # 2 发送短信
    res = x.run(phone, code)
    # 3 返回信息
    print(res)

# @app.task
def send_email_sms(email,code):
    subject = "【牛笔】账号安全中心-设置邮箱验证"
    message = "您正在牛笔进行换绑邮箱的操作，本次请求的邮件验证码是：%s(为了保证您账号的安全性，请您在5分钟内完成验证).\
     为保证账号安全，请勿泄漏此验证码。\
      祝在【牛笔】收获愉快！"%code

    from_email = settings.EMAIL_HOST_USER
    recipient_list = [email]
    x = QqEmail(subject,message,from_email,recipient_list)
    x.run(email,code)
