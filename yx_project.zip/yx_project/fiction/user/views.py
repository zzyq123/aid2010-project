import hashlib
import json
import random
import time

import jwt
import redis
from django.conf import settings
from django.core.cache import cache
from django.http import JsonResponse
from django.shortcuts import render

# Create your views here.
from django.utils.decorators import method_decorator
from django.views import View

from book.models import Book
from tools.login_check import login_check
from .task import send_sms
from user.models import UserProfile


class UserView(View):
    # 为前端返回用户注册的数据判断
    def post(self,request):
        json_str = request.body
        json_obj = json.loads(json_str)
        username = json_obj["username"]
        password_1 = json_obj["password_1"]
        password_2 = json_obj["password_2"]
        phone = json_obj["phone"]
        sms_num = json_obj["sms_num"]
        # 不允许乱输入验证码
        try:
            int(sms_num)
        except:
            result = {"code": 10606, "error": "请输入正确的验证码"}
            return JsonResponse(result)
        if not sms_num:
            result = {"code":10005,"error":"请输入验证码"}
            return JsonResponse(result)
        if not password_1:
            result = {"code": 10006, "error": "请输入密码"}
            return JsonResponse(result)
        if not username:
            result = {"code": 10007, "error": "请输入用户名"}
            return JsonResponse(result)
        # 本网站可使用绑定过的手机登录，为防止用户注册时用纯数字导致后续手机号不可使用
        try:
            int(username)
        except:
            resent_user = UserProfile.objects.filter(username =username)
            if resent_user:
                result = {"code":10001,"error":"用户名已存在"}
                return JsonResponse(result)
            if password_1 !=password_2:
                result = {"code":10002,"error":"两次密码不一样"}
                return JsonResponse(result)
            cache_key = 'sms_%s' % phone
            code = cache.get(cache_key)
            if not code:
                result = {"code":10003,"error":"获取验证码超时,请重新获取"}
                return JsonResponse(result)
            if code != int(sms_num):
                result = {"code":10004,"error":"输入的验证码错误"}
                return JsonResponse(result)
            md5 = hashlib.md5()
            md5.update(password_1.encode())
            password_true = md5.hexdigest()
            try:
                UserProfile.objects.create(username=username,
                                           password=password_true,
                                           nickname=username,
                                           phone = phone
                                           )
            except:
                return JsonResponse({"code":10008,"error":"用户名已存在"})
            r = redis.Redis()
            r.hmset(username+"_data",{"balance":0,"ticket":0,"collection_count":0})
            token = make_token(username).decode()
            result = {"code":200,"username":username,"token":token}
            return JsonResponse(result)
        result = {"code":10000,"error":"用户名不可为纯数字"}
        return JsonResponse(result)

    @method_decorator(login_check)
    # 为前端个人中心提供一些用户基本信息
    def get(self,request):
        nickname = request.myuser.nickname
        username = request.myuser.username
        phone = request.myuser.phone
        sign = request.myuser.sign
        question = ""
        identity = ""
        email = request.myuser.email
        r = redis.Redis()
        balance = r.hget(username+"_data","balance").decode()
        ticket = r.hget(username+"_data","ticket").decode()
        collection_count = r.hget(username + "_data", "collection_count").decode()
        result = {"code":200,"data":{"nickname":nickname,
                                     "phone":phone,
                                     "sign":sign,
                                     "question":question,
                                     "identity":identity,
                                     "email":email,
                                     "balance":balance,
                                     "ticket":ticket,
                                     "collection_count":collection_count}}
        return JsonResponse(result)

    @method_decorator(login_check)
    # 为前端进行修改昵称判断
    def put(self,request):
        json_str = request.body
        json_obj = json.loads(json_str)
        sign = json_obj["sign"]
        nickname = json_obj["nickname"]
        user = request.myuser
        if user.nickname != nickname:
            users = UserProfile.objects.filter(nickname=nickname)
            if users:
                result = {"code":10410,"error":"该昵称已存在"}
                return JsonResponse(result)
        user.sign = sign
        user.nickname = nickname
        user.save()
        result = {"code":200}
        return JsonResponse(result)

# 制作token，过期时间为一个星期
def make_token(username,expire=3600*24*7):
    key = settings.JWT_TOKEN_KEY
    now = time.time()
    payload = {"username":username,"expire":now+expire}
    return jwt.encode(payload,key,algorithm="HS256")

# 为用户注册时发送短信验证码
def sms_view(request):
    # 1 获取前段提交的数据
    json_str = request.body
    # 2 json串反序列化为对象
    json_obj = json.loads(json_str)
    # 3 获取手机号
    phone = json_obj['phone']
    if len(phone) != 11:
        result = {"code":10611,"error":"请输入正确的手机号"}
        return JsonResponse(result)
    if not phone:
        result = {"code":10612,"error":"请输入手机号"}
        return JsonResponse(result)
    users = UserProfile.objects.filter(phone=phone)
    if users:
        result = {"code": 10612, "error": "手机已被绑定"}
        return JsonResponse(result)
    # 4 生成随机验证码
    code = random.randint(1000, 9999)
    # 5 将验证码存储到缓存（redis）中
    cache_key = 'sms_%s' % phone
    cache.set(cache_key, code, 180)
    print(phone, code)

    # 异步方式
    send_sms.delay(phone, code)
    print(phone, code)
    return JsonResponse({'code': 200})

# 只作为一个用户登录验证
@login_check
def check_login(request):
    if request.method == "GET":
        result = {"code":200}
        return JsonResponse(result)




