import hashlib
import json

from django.http import JsonResponse
from django.shortcuts import render

# Create your views here.
from django.views import View
from user.views import make_token
from user.models import UserProfile


class LoginView(View):
    # 为前端返回登录数据判断
    def post(self,request):
        json_str =request.body
        json_obj = json.loads(json_str)
        username = json_obj["username"]
        password = json_obj["password"]
        if not username:
            result = {"code": 10413, "error": "请输入用户名/手机号"}
            return JsonResponse(result)
        if not password:
            result = {"code": 10414, "error": "请输入密码"}
            return JsonResponse(result)
        try:
            user = UserProfile.objects.get(username=username)
        except:
            try:
                user = UserProfile.objects.get(phone=username)
            except:
                result = {"code":10410,"error":"用户名或密码错误"}
                return JsonResponse(result)
        md5 = hashlib.md5()
        md5.update(password.encode())
        password_true = md5.hexdigest()
        if password_true != user.password:
            result = {"code":10412,"error":"用户名或密码错误"}
            return JsonResponse(result)
        username = user.username
        token = make_token(username).decode()
        result = {"code":200,"username":username,"token":token}
        return JsonResponse(result)