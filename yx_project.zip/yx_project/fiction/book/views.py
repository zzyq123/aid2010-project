import json

import redis
from django.http import JsonResponse
from django.shortcuts import render

# Create your views here.
from django.views import View


class BookView(View):
    def get(self,request,bookname):
        result = {"code":200}
        return JsonResponse(result)

    def post(self,request,bookname):
        #获取前端提交数据（投票数量）
        json_str = request.body
        json_obj = json.loads(json_str)
        ticket_count = json_obj['ticket_count']
        r = redis.Redis()
        #为对应的元素增加投票数量
        r.zincrby(name="zk1",value=bookname,amount=ticket_count)
        result = {"code":200}
        return JsonResponse(result)