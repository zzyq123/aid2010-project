import json

import redis
from django.http import JsonResponse
from django.shortcuts import render

# Create your views here.
from django.utils.decorators import method_decorator
from django.views import View

from book.models import Book
from comment.models import Comment
from tools.login_check import login_check


class BookView(View):
    @method_decorator(login_check)
    # 为前段返回作品详情和评论区内容
    def get(self,request,bookname):
        title = bookname
        try:
            book = Book.objects.get(title = title)
        except:
            result = {"code":10500,"error":"没有该图书"}
            return JsonResponse(result)
        content = book.content
        comment_list = self.make_comments(book)
        result = {"code":200,"data":{"title":title,"content":content,"comments":comment_list}}
        return JsonResponse(result)

    # 构建前段评论区内容所需json串
    def make_comments(self,book):
        comments = Comment.objects.filter(book=book).order_by('-created_time')
        comment_list = []
        r_dict = {}
        # r_r_dict = {}
        for comment in comments:
            if comment.parent_message:
                #回复
                r_dict.setdefault(comment.parent_message, [])
                r_dict[comment.parent_message].append({
                    'reply_id': comment.id,
                    'rid':comment.rid,
                    'reply_content': comment.content,
                    'publisher': comment.user_profile.username,
                    'created_time': comment.created_time.strftime('%Y-%m-%d %H:%M:%S'),
            })
                print(1)
            else:
                #评论
                comment_list.append({
                    'id': comment.id,
                    'comment_content': comment.content,
                    'publisher': comment.user_profile.username,
                    'created_time': comment.created_time.strftime('%Y-%m-%d %H:%M:%S'),
                    'reply': []
                })
        for c in comment_list:
            if c['id'] in r_dict:
                c['reply'] = r_dict[c['id']]
        result = comment_list
        print(result)
        return result

# 上传作品，并构建所有作品所需redis库（测试用）
@login_check
def uploadbook(request):
    if request.method == "POST":
        json_str = request.body
        json_obj = json.loads(json_str)
        title = json_obj["title"]
        content = json_obj["content"]
        category = json_obj["category"]
        author = request.myuser
        result = save_data(title, content,category, author)
        if result:
            return result
        result = {"code":200}
        return JsonResponse(result)
    else:
        result = {"code": 10406, "error": "图书上传失败"}
        return JsonResponse(result)

def save_data(title,content,category,author):
    try:
        Book.objects.create(title=title,
                            content=content,
                            category=category,
                            user_profile=author
                            )
    except:
        result = {"code": 10408, "error": "图书上传失败"}
        return JsonResponse(result)
    ticket = 0
    reward = 0
    scan = 0
    collection = 0
    subscription = 0
    hot = ticket*100 + reward + scan*10 + collection*10 + subscription
    r = redis.Redis()
    try:
        r.zadd(category+"_hot",{title:hot})
        r.zadd(category+"_ticket",{title:ticket})
        r.zadd(category+"_reward",{title:reward})
        r.zadd(category+"_scan",{title:scan})
        r.zadd(category+"_collection",{title:collection})
        r.zadd(category+"_subscription",{title:subscription})
        r.zadd("total_hot", {title: hot})
        r.zadd("total_ticket", {title: ticket})
        r.zadd("total_reward", {title: reward})
        r.zadd("total_scan", {title: scan})
        r.zadd("total_collection", {title: collection})
        r.zadd("total_subscription", {title: subscription})

    except:
        result = {"code": 10407, "error": "图书上传失败"}
        return JsonResponse(result)