from django.db import models

# Create your models here.
from book.models import Book
from user.models import UserProfile


class Comment(models.Model):
    content = models.CharField('内容', max_length=70)
    created_time = models.DateTimeField(auto_now_add=True)
    parent_message = models.IntegerField(default=0)
    rid = models.IntegerField(default=0)
    book = models.ForeignKey(Book, on_delete=models.CASCADE)
    user_profile = models.ForeignKey(UserProfile,
                                     on_delete=models.CASCADE)
