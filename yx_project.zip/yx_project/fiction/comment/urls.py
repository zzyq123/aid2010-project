from django.urls import path

from comment import views

urlpatterns = [
    path('<str:bookname>',views.CommentView.as_view())
]