import json

from django.http import JsonResponse
from django.shortcuts import render

# Create your views here.
from django.utils.decorators import method_decorator
from django.views import View

from book.models import Book
from comment.models import Comment
from tools.login_check import login_check


class CommentView(View):
    @method_decorator(login_check)
    # 保存评论区内容到MySQL数据库中
    def post(self,request,bookname):
        print(1)
        json_str = request.body
        json_obj = json.loads(json_str)
        comment_content = json_obj["comment_content"]
        print(comment_content)
        title = bookname
        author = request.myuser
        parent_id = json_obj.get('parent_id', 0)
        rid = json_obj.get("rid",0)
        try:
            book = Book.objects.get(title = title)
        except:
            result = {'code': 10511, 'error': '没有该图书！'}
            return JsonResponse(result)
        if not comment_content:
            result = {"code":10512,"error":"内容不可为空"}
            return JsonResponse(result)
        Comment.objects.create(content=comment_content,
                               parent_message = parent_id,
                               rid = rid,
                               user_profile = author,
                               book = book)
        return JsonResponse({"code":200})


