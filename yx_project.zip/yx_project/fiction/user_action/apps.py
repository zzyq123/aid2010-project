from django.apps import AppConfig


class UserActionConfig(AppConfig):
    name = 'user_action'
