from django.urls import path
from . import views

urlpatterns = [
    path('<str:bookname>',views.UserActionView.as_view()),
]