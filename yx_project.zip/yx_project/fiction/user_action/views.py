import json
import time

import redis
from django.http import JsonResponse
from django.shortcuts import render

# Create your views here.
from django.utils.decorators import method_decorator
from django.views import View

from book.models import Book
from tools.login_check import login_check
from user_record_expense.models import ExpenseRecord
from user_record_ticket.models import TicketRecord


class UserActionView(View):
    #用户投票，收藏，订阅，打赏等行为
    @method_decorator(login_check)
    def put(self,request,bookname):
        title = bookname
        try:
            book = Book.objects.get(title=title)
        except:
            result = {"code": 10501, "error": "没有该图书"}
            return JsonResponse(result)
        json_str = request.body
        json_obj = json.loads(json_str)
        user = request.myuser
        if json_obj["ticket_count"]:
            ticket_count= json_obj["ticket_count"]
            res = user_ticket(title,ticket_count,book,user)
            return res
        if json_obj["reward_count"]:
            balance_count = json_obj["reward_count"]
            ExpenseRecord.objects.create(title=title,
                                        reward_count=balance_count,
                                        user_profile=user
                                        )
            res = user_balance(title,balance_count,book,user,json_obj)
            return res
        if json_obj["subscription_count"]:
            balance_count = json_obj["subscription_count"]
            ExpenseRecord.objects.create(title=title,
                                        subscription_count=balance_count,
                                        user_profile=user
                                        )
            res = user_balance(title, balance_count, book, user, json_obj)
            return res

    #为用户充值，测试时使用，正式的充值入口不在这里
    @method_decorator(login_check)
    def post(self,request):
        json_str = request.body
        json_obj = json.loads(json_str)
        user = request.myuser
        if json_obj["recharge_ticket"]:
            recharge_ticket = json_obj["recharge_ticket"]
            r= redis.Redis()
            r.hincrby(user.username + "_data","ticket",recharge_ticket)
            result = {"code":200}
            return JsonResponse(result)
        if json_obj["recharge_balance"]:
            recharge_balance = json_obj["recharge_balance"]
            r= redis.Redis()
            r.hincrby(user.username + "_data","balance",recharge_balance)
            result = {"code":200}
            return JsonResponse(result)

# 用户操作月票结果
def user_ticket(title,ticket_count,book,user):
    r = redis.Redis()
    ticket = r.hget(user.username + "_data", "ticket")
    if int(ticket) < int(ticket_count):
        result = {"code": 10502, "error": "您的月票不足"}
        return JsonResponse(result)
    hot = int(ticket_count)*100
    # 减去用户使用的月票
    r.hincrby(user.username + "_data","ticket", "-"+ticket_count)
    # 增加书分类的热度排行值
    r.zincrby(name=book.category + "_hot", value=title, amount=hot)
    # 增加书分类的月票排行值
    r.zincrby(name=book.category + "_ticket", value=title, amount=ticket_count)
    # 增加总的热度排行值
    r.zincrby("total_hot", value=title, amount=hot)
    # 增加总的月票排行值
    r.zincrby(name="total_ticket", value=title, amount=ticket_count)
    # 判断此书有无该用户粉丝和此书有无粉丝
    if not r.zscore(title + "_fans", user.nickname):
        r.zadd(title + "_fans", {user.nickname: 0})
    # 增加该用户对此书的粉丝值
    r.zincrby(name=title + "_fans", value=user.nickname, amount=hot)
    # 添加用户投月票记录
    TicketRecord.objects.create(title=title,
                                ticket_count=ticket_count,
                                user_profile=user
                                )
    result = {"code": 200,"data":"您的粉丝值提升了%s点"%hot}
    return JsonResponse(result)

# 用户消费的结果
def user_balance(title,balance_count,book,user,json_obj):
    r = redis.Redis()
    balance = r.hget(user.username + "_data", "balance")
    if int(balance) < int(balance_count):
        result = {"code": 10502, "error": "您的牛币不足"}
        return JsonResponse(result)
    hot = balance_count
    # 减去用户使用的牛币
    r.hincrby(user.username + "_data","balance", "-"+balance_count)
    # 每消费100点牛币，增加一张月票
    add_ticket = int(balance_count)//100
    r.hincrby(user.username + "_data", "ticket", add_ticket)
    # 增加书分类的热度排行值
    r.zincrby(name=book.category + "_hot", value=title, amount=hot)
    if json_obj["reward_count"]:
    # 增加书分类的打赏排行值
        r.zincrby(name=book.category + "_reward", value=title, amount=balance_count)
        # 增加总的打赏排行值
        r.zincrby(name="total_reward", value=title, amount=balance_count)
    if json_obj["subscription_count"]:
        # 增加书分类的订阅排行值
        r.zincrby(name=book.category + "_subscription", value=title, amount=balance_count)
        # 增加总的订阅排行值
        r.zincrby(name="total_subscription", value=title, amount=balance_count)
    # 增加总的热度排行值
    r.zincrby("total_hot", value=title, amount=hot)

    # 判断此书有无该用户粉丝和此书有无粉丝
    if not r.zscore(title + "_fans", user.nickname):
        r.zadd(title + "_fans", {user.nickname: 0})
    # 增加该用户对此书的粉丝值
    r.zincrby(name=title + "_fans", value=user.nickname, amount=hot)
    result = {"code": 200,"data":"您的月票增加了%s张,粉丝值提升了%s点"%(add_ticket,hot)}
    return JsonResponse(result)