from django.apps import AppConfig


class UserSecurityPasswordConfig(AppConfig):
    name = 'user_security_password'
