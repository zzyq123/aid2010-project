import hashlib
import json

from django.core.cache import cache
from django.http import JsonResponse
from django.shortcuts import render

# Create your views here.
from django.utils.decorators import method_decorator
from django.views import View

from tools.login_check import login_check
from tools.verify import verify


class UserSecurityPasswordView(View):
    @method_decorator(login_check)
    @method_decorator(verify)
    #验证身份后修改密码
    def put(self,request):
        json_str = request.body
        json_obj = json.loads(json_str)
        password_1 = json_obj["password_1"]
        password_2 = json_obj["password_2"]
        if not password_1:
            result = {"code":10611,"error":"请输入密码"}
            return JsonResponse(result)
        if password_1 != password_2:
            result = {"code":10610,"error":"两次密码请保持一致"}
            return JsonResponse(result)
        md5 = hashlib.md5()
        md5.update(password_1.encode())
        password_h = md5.hexdigest()
        user = request.myuser
        if password_h == user.password:
            result = {"code":10612,"error":"新密码不能与老密码一致"}
            return JsonResponse(result)

        user.password = password_h
        user.save()
        result = {"code": 200}
        return JsonResponse(result)