from django.urls import path
from . import views
urlpatterns = [
    path('mail_verify',views.mail_verify),
]