from django.apps import AppConfig


class UserSecurityMailConfig(AppConfig):
    name = 'user_security_mail'
