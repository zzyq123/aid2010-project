import json
import random

from django.core.cache import cache
from django.http import JsonResponse
from django.shortcuts import render

# Create your views here.
from django.utils.decorators import method_decorator
from django.views import View

from tools.login_check import login_check
from tools.verify import verify
from user.models import UserProfile
from user.task import send_email_sms


class UserSecurityMailView(View):
    #更改邮箱时生成并发送邮箱验证码
    @method_decorator(login_check)
    def post(self,request):
        json_str = request.body
        json_obj = json.loads(json_str)
        mail = json_obj["mail"]
        if not mail:
            result = {"code":10621,"error":"请输入邮箱"}
            return JsonResponse(result)
        users = UserProfile.objects.filter(email = mail)
        if users:
            result = {"code":10620,"error":"该邮箱已被绑定"}
            return JsonResponse(result)
        code = random.randint(100000,999999)
        cache_key = "sms_email%s" % mail
        cache.set(cache_key,code,300)
        print(mail,code)
        try:
            send_email_sms(mail,code)
        except:
            result = {"code":10622,"error":"请输入正确的邮箱地址"}
            return JsonResponse(result)
        print(mail, code)
        result = {"code":200}
        return JsonResponse(result)

    #邮箱验证身份时生成并发送邮箱验证码
    @method_decorator(login_check)
    def get(self,request):
        user = request.myuser
        mail = user.email
        code = random.randint(100000, 999999)
        cache_key = 'sms_email%s' % mail
        cache.set(cache_key, code, 300)
        print(mail, code)
        send_email_sms(mail, code)
        print(mail, code)
        return JsonResponse({'code': 200})

    @method_decorator(login_check)
    @method_decorator(verify)
    #验证身份后修改邮箱
    def put(self,request):
        json_str = request.body
        json_obj = json.loads(json_str)
        mail_sms_num = json_obj["mail_sms_num"]
        mail = json_obj["mail"]
        try:
            int(mail_sms_num)
        except:
            result = {"code": 10606, "error": "请输入正确的验证码"}
            return JsonResponse(result)
        if not mail:
            result = {"code": 10631, "error": "请输入邮箱"}
            return JsonResponse(result)
        if not mail_sms_num:
            result = {"code": 10632, "error": "请输入验证码"}
            return JsonResponse(result)
        users = UserProfile.objects.filter(email=mail)
        if users:
            result = {"code": 10633, "error": "该邮箱已被绑定"}
            return JsonResponse(result)
        cache_key = "sms_email%s" % mail
        code = cache.get(cache_key)
        if not code:
            result = {"code": 10634, "error": "获取验证码超时,请重新获取"}
            return JsonResponse(result)
        if code != int(mail_sms_num):
            result = {"code": 10635, "error": "输入的验证码错误"}
            return JsonResponse(result)
        user = request.myuser
        user.email = mail
        user.save()
        result = {"code": 200}
        return JsonResponse(result)

#邮箱验证身份时判断邮箱验证码
@login_check
def mail_verify(request):
    if request.method == "POST":
        json_str = request.body
        json_obj = json.loads(json_str)
        mail_sms_num = json_obj["mail_sms_num"]
        user = request.myuser
        mail = user.email
        if not mail_sms_num:
            result = {"code":10602,"error":"请输入验证码"}
            return JsonResponse(result)
        try:
            int(mail_sms_num)
        except:
            result = {"code": 10606, "error": "请输入正确的验证码"}
            return JsonResponse(result)

        cache_key = "sms_email%s"%mail
        code = cache.get(cache_key)
        if not code:
            result = {"code": 10600, "error": "获取验证码超时,请重新获取"}
            return JsonResponse(result)
        if code != int(mail_sms_num):
            result = {"code": 10601, "error": "输入的验证码错误"}
            return JsonResponse(result)
        result ={"code":200}
        return JsonResponse(result)
