import json
import random

from django.core.cache import cache
from django.http import JsonResponse
from django.shortcuts import render

# Create your views here.
from django.utils.decorators import method_decorator
from django.views import View

from tools.login_check import login_check
from tools.verify import verify
from user.models import UserProfile
from user.task import send_sms


class UserSecurityPhoneView(View):
    #手机验证身份时判断验证码
    @method_decorator(login_check)
    def post(self,request):
        json_str = request.body
        json_obj = json.loads(json_str)
        sms_num = json_obj["sms_num"]
        user = request.myuser
        phone = user.phone
        try:
            int(sms_num)
        except:
            result = {"code": 10606, "error": "请输入正确的验证码"}
            return JsonResponse(result)
        if not sms_num:
            result = {"code":10602,"error":"请输入验证码"}
            return JsonResponse(result)
        cache_key = "sms_%s"%phone
        code = cache.get(cache_key)
        if not code:
            result = {"code": 10600, "error": "获取验证码超时,请重新获取"}
            return JsonResponse(result)
        if code != int(sms_num):
            result = {"code": 10601, "error": "输入的验证码错误"}
            return JsonResponse(result)
        result ={"code":200}
        return JsonResponse(result)

    @method_decorator(login_check)
    #手机验证身份时生成验证码并发送验证码
    def get(self,request):
        user = request.myuser
        phone = user.phone
        code = random.randint(1000, 9999)
        cache_key = 'sms_%s' % phone
        cache.set(cache_key, code, 300)
        print(phone, code)
        send_sms.delay(phone, code)
        print(phone, code)
        return JsonResponse({'code': 200})

    @method_decorator(login_check)
    @method_decorator(verify)
    #手机验证身份修改手机
    def put(self,request):
        json_str = request.body
        json_obj = json.loads(json_str)
        sms_num = json_obj["sms_num"]
        phone_new = json_obj["phone"]
        try:
            int(sms_num)
        except:
            result = {"code": 10606, "error": "请输入正确的验证码"}
            return JsonResponse(result)
        if not phone_new:
            result = {"code": 10604, "error": "请输入手机号"}
            return JsonResponse(result)
        if not sms_num:
            result = {"code": 10602, "error": "请输入验证码"}
            return JsonResponse(result)
        cache_key = "sms_%s" % phone_new
        code = cache.get(cache_key)
        if not code:
            result = {"code": 10600, "error": "获取验证码超时,请重新获取"}
            return JsonResponse(result)
        if code != int(sms_num):
            result = {"code": 10601, "error": "输入的验证码错误"}
            return JsonResponse(result)
        users = UserProfile.objects.filter(phone=phone_new)
        if users:
            result = {"code": 10605, "error": "手机已被绑定"}
            return JsonResponse(result)
        user = request.myuser
        user.phone = phone_new
        user.save()
        result = {"code": 200}
        return JsonResponse(result)
