from django.apps import AppConfig


class UserSecurityConfig(AppConfig):
    name = 'user_security_phone'
